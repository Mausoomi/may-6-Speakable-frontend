import React from 'react'

const MyAvatar = () => {

    const MyAvatar = {
        width:'50px',
        height:'50px',
        display:'flex',
        justifyContent:'center',
        alignItems:'center',
        borderRadius:'50%',
        backgroundColor:'#33906c',
        marginRight:"10px",
        color:"white",
        fontSize:"20px"
    }



  return (
    <div style={MyAvatar}>A</div>
  )
}

export default MyAvatar